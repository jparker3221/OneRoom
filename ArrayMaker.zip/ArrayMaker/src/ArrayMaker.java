import java.util.Scanner;

/**
 * Created by jparker3221 on 8/30/2016.
 */
        public class ArrayMaker {


            static int[] array;//our beautiful array
            static Scanner input = new Scanner(System.in);//this checks user input
            static int inputAnswer;

            public static void main(String[] args) {
                driver();
    }
    public static void driver(){
        System.out.println("pick a number to count to");
        inputAnswer = input.nextInt();
        array = new int[inputAnswer];
        for(int i = 0; i<inputAnswer; i++){// this counts up to the last number in the array
            array[i] = i;
            System.out.println(array[i]+1);

        }
        driver();//loops the code
    }

}
